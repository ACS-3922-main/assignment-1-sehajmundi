﻿using System;
//Sehaj Mundi
//3117464
namespace assignment_1
{
    class Card
    {
        public Suit _suit;
        public Rank _rank;

        public Card(Suit suit, Rank rank)
        {
            this._suit = suit;
            this._rank = rank;
        }

        public Suit cardSuit
        {
            get{return _suit;}
            set{_suit = value;}
        }

        public Rank cardRank
        {
            get{return _rank;}
            set{_rank = value;}
        }

        public override string ToString()
        {
            return _rank+" of "+_suit;
        }
    }
}
