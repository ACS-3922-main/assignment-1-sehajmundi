using System;
using System.Collections.Generic;
//Sehaj Mundi
//3117464

namespace assignment_1
{
    class Hand : SetOfCards
    {
        int checkType;
        String HandType;
        public Hand()
        {
            max = 5;
        }

        public override string Evaluate()
        {
            
            if(CheckStraightFlush() == 2)
            {
                checkType = 2;
            }
            else if(CheckStraight() == 1)
            {
                checkType = 1;
            }
            else if(CheckFlush() == 3)
            {
                checkType = 3;
            }
            else
            {
                checkType = 0;
            }

            switch(checkType)
            {
                case 1: HandType = "Flush";
                break;
                case 2: HandType = "Straight";
                break;
                case 3: HandType = "Staright Flush";
                break;
                default: HandType = "Nothing";
                break;
            }
            return HandType;  
        }
        public Rank GetHighCard()
        {
            List<int> valOfHand = new List<int>();
            foreach(Card c in this._cards)
            {
                valOfHand.Add((int)c._rank);
            }
            valOfHand.Sort();
            return (Rank)valOfHand[4];               
        }

        public int CheckStraight()
        {
            int check = 0;
            int i = 0;

            while(i < _cards.Count - 1)
            {
                if(!(_cards[i].cardRank.Equals(_cards[i+1]._rank)))
                {
                    return check = 0;
                }
                else
                {
                    i++;
                }
            }
            check = 1;
            return check;
        }

        public int CheckStraightFlush()
        {
            int check = 0;
            int i = 0;

            while(i < _cards.Count - 1)
            {
                if(!(_cards[i].cardRank.Equals(_cards[i+1]._rank)))
                {
                    return check = 0;
                }
                else
                {
                    i++;
                }
            }
            check = 2;
            return check;
        }

        public int CheckFlush()
        {
            int check = 0;
            int i = 0;

            while(i < _cards.Count - 1)
            {
                if(!(_cards[i].cardRank.Equals(_cards[i+1]._rank)))
                {
                    return check = 0;
                }
                else
                {
                    i++;
                }
            }
            check = 3;
            return check;
        }

        private bool CheckNumberOfRanks(int number)
        {
            bool b = false;

            int[] array = new int[14];

            for (int i = 0; i < 14; i++)
            {
                array[i] = 0;
            }


            foreach (Card card in _cards)
            {
                array[(int)card._rank] += 1;
            }

            foreach(int i in array)
            {
                if(i == number)
                {
                    b = true;
                }
            }

            return b;
        }
    }
}