using System;
//Sehaj Mundi
//3117464
namespace assignment_1
{
    class Rank
    {
        public enum rank
        {
            Two = 2 , Three, Four, Five, Six, Seven, Eight, Nine, Ten, Jack, Queen, King, Ace    
        }
    }
}
