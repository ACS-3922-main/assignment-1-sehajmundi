using System;
using System.Collections.Generic;
//Sehaj Mundi
//3117464
namespace assignment_1
{
    class PokerHandSim
    {
        static void Main(string[] args)
        {
            Deck deck = new Deck();
            deck.ShuffleCards();

            Hand h1 = new Hand();
            Hand h2 = new Hand();
            Hand h3 = new Hand();
            Hand h4 = new Hand();

            for(int i = 0; i<5; i++)
            {
                h1.addCards(deck.Deal());
                h2.addCards(deck.Deal());
                h3.addCards(deck.Deal());
                h4.addCards(deck.Deal());
            }

            Console.WriteLine("Player 1: \n"+h1+"\n"+h1.Evaluate());
            Console.WriteLine("Player 2: \n"+h2+"\n"+h2.Evaluate());
            Console.WriteLine("Player 3: \n"+h3+"\n"+h3.Evaluate());
            Console.WriteLine("Player 4: \n"+h4+"\n"+h4.Evaluate());
        }
    }

}