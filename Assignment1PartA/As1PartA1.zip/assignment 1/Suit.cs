using System;

namespace assignment_1
{
    class Suit
    {
        public enum suit
        {
             Hearts = 1, Diamonds, Clubs, Spades 
        }

    }
}