using System;
using System.Collections.Generic;
//Sehaj Mundi
//3117464
namespace assignment_1
{
    class Deck : SetOfCards
    {
        public Deck()
        {
            max = 52;
            CreateCards();
        }

        private void CreateCards()
        {
            foreach(Suit s in Enum.GetValues(typeof(Suit)))
            {
                foreach(Rank r in Enum.GetValues(typeof(Rank)))
                {
                    addCards(new Card(s, r));
                }
            }
        }

        public void ShuffleCards()
        {
            Random rand = new Random();
            Card temp;
            for(int shuffleAmount = 0; shuffleAmount< 100; shuffleAmount++)
            {
                for(int i = 0; i<max; i++)
                {
                    int index = rand.Next(13);
                    temp = _cards[i];
                    _cards[i] = _cards[index];
                    _cards[index] = temp;
                }
            }

        }

        public Card Deal()
        {
            return _cards.RemoveAt(0);
        }

        public override string Evaluate()
        {
            return "Number of cards  in deck:" + _cards.Count;
        }
    }
}