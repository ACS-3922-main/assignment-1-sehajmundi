using System;
using System.Collections.Generic;
//Sehaj Mundi
//3117464
namespace assignment_1
{
    abstract class SetOfCards
    {
        public List<Card> _cards;
        public int max;

        public SetOfCards()
        {
            _cards = new List<Card>(max);
        }

        public List<Card> Cards
        {
            get{return _cards;}
            set{_cards = value;}
        }

        public void addCards(Card c)
        {
            _cards.Add(c);
        }

        public abstract string Evaluate();

        public override string ToString()
        {
            String s = "";
            
            s +="[";
            for (int i = 0; i<_cards.Count;i++) 
            {
                   s+= _cards[i].ToString()+",";
            }
            return s;
        }
    }
}